<?php
//define('WP_HOME','http://reservdn.local/');
//define('WP_SITEURL','http://reservdn.local/');

define('WP_HOME','http://dnasikt.local/');
define('WP_SITEURL','http://dnasikt.local/');

/** MySQL database username */
//define('DB_USER', 'wp');

/** MySQL database password */
//define('DB_PASSWORD', '12345678');

/** MySQL hostname */
//define('DB_HOST', '10.10.21.52');

/** The name of the database for WordPress */
	// define('DB_NAME', 'dnfokus_v1');
	define('DB_NAME', 'dnasikt');

    /** MySQL database username */
    define('DB_USER', 'root');
    // define('DB_USER', 'root');    

    /** MySQL database password */
    // define('DB_PASSWORD', '');
    define('DB_PASSWORD', '');
    

    /** MySQL hostname */
    define('DB_HOST', 'localhost');
    // define('DB_HOST', 'localhost');