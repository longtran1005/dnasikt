Instruktioner
======

1. **git clone**
2. Kopiera **RENAME-config.php** och lägg den en mapp upp i mappstrukturen
  1. Döp filen till något av de tre valen nedan.
  	* local-config.php - Utveckling
  	* stage-config.php - Stage
  	* prod-config.php - Produktion
  2. Lägg in rätt databas-kriterier i filen
3. cd ..../wp-content/themes/LightWeightStarterTheme/assets/
4. **npm install**
5. Sist men inte minst **grunt**
    * Det finns även
    * **grunt dev**
    * **grunt prod**